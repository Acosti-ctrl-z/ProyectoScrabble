package com.example.demousuario;

import javafx.scene.control.Label;

public class ModificarDatosCommand implements Commands{

    private Device device;

    public ModificarDatosCommand(Device device) {
        this.device = device;
    }

    @Override
    public void execute(Label label) {
        device.modificarDatos(label);
    }
}
