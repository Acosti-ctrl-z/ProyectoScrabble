package com.example.demousuario;

import javafx.scene.control.Label;

public class ListaPartidaCommand implements Commands{

    private Device device;

    public ListaPartidaCommand(Device device) {
        this.device = device;
    }

    @Override
    public void execute(Label label) {
        device.listaPartdia(label);
    }
}
