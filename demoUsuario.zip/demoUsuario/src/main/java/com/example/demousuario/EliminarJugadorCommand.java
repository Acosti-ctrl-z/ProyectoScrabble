package com.example.demousuario;

import javafx.scene.control.Label;

public class EliminarJugadorCommand implements Commands{

    private Device device;

    public EliminarJugadorCommand(Device device) {
        this.device = device;
    }

    @Override
    public void execute(Label label) {
        device.eliminarJugador(label);
    }
}
