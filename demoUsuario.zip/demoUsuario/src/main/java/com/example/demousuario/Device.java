package com.example.demousuario;

import javafx.scene.control.Label;

public class Device {

    public void agregarJugador(Label label) {
        label.setText("El jugador a sido registrado");

    }

    public void estadisticasMostrar(Label label) {
        label.setText("Mostrando estadisticas");
    }

    public void modificarDatos(Label label) {
        label.setText("Datos modificados");

    }

    public void eliminarJugador(Label label) {
        label.setText("El jugador a sido eliminado");
    }

    public void listaPartdia(Label label) {
        label.setText("Mostrando Partidas");
    }

}
