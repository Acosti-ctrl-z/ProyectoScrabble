package com.example.demousuario;

import Datos.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import javafx.scene.control.TextField;
import javafx.stage.Stage;


import java.io.IOException;
import java.util.Objects;


public class AgregarController {

    @FXML
    private Button BotonAgregar;

    @FXML
    protected void onAgregarUsuarioClick() throws IOException {
        Stage stage = (Stage) BotonAgregar.getScene().getWindow();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("AgregarUsuario.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    @FXML
    private Button BotonEstadisticas;

    @FXML
    protected void onVerEstadisticasClick() throws IOException {
        Stage stage = (Stage) BotonEstadisticas.getScene().getWindow();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Estadisticas.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    @FXML
    private Button BotonModificar;

    @FXML
    protected void onModificarDatosClick() throws IOException {
        Stage stage = (Stage) BotonModificar.getScene().getWindow();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("ModificarDatos.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    @FXML
    private Button BotonEliminar;

    @FXML
    protected void onEliminarJugadorClick() throws IOException {
        Stage stage = (Stage) BotonEliminar.getScene().getWindow();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("EliminarJugador.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    @FXML
    private Button BotonLista;

    @FXML
    protected void onMostrarListaClick() throws IOException {
        Stage stage = (Stage) BotonLista.getScene().getWindow();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("ListaPartidas.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    @FXML
    private Button BotonRegresar;

    @FXML
    protected void onRegresarMenuClick() throws IOException {
        Stage stage = (Stage) BotonRegresar.getScene().getWindow();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Menu.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    @FXML
    private TextField nombreJtext;

    @FXML
    private TextField correoJtext;

    @FXML
    private ListaUsuarios users = new ListaUsuarios();

    @FXML
    private Label agregarText;

    @FXML
    protected void registroJugador(){
        Device device = new Device();
        Commands agregarJugador = new AgregarJugadorCommand(device);
        Boton boton = new Boton();

        this.users = LectorJson.leerDatos(this.users, "ListaUsuarios");
        String name = nombreJtext.getText();
        String email = correoJtext.getText();
        this.users.agregarUsuarioNuevo(name, email);
        EscritorJson.guardarDatos(this.users, "ListaUsuarios");

        boton.setCommands(agregarJugador);
        boton.pressButton(agregarText);
    }

    @FXML
    private Label estadisticasText;

    @FXML
    private TextField indiceJtext;

    @FXML
    private Label nombreText;

    @FXML
    private Label correoText;

    @FXML
    private Label palabrasText;

    @FXML
    private Label puntajeText;

    @FXML
    private Label partidasText;
    @FXML

    protected void estadisticasJugador(){
        Device device = new Device();
        Commands estadisticasMostrar = new EstadisticasMostrarCommand(device);
        Boton boton = new Boton();

        this.users = LectorJson.leerDatos(this.users, "ListaUsuarios");
        int indice = Integer.parseInt(indiceJtext.getText());
        if (users.getListaUsuarios()!= null && !users.getListaUsuarios().isEmpty()) {
            if (indice >= 1 && indice <= users.getListaUsuarios().size()) {
                System.out.println("Objetivo encontrado.");
                Usuario user = users.getListaUsuarios().get(indice - 1);
                nombreText.setText("Nombre: " + user.getAlias());
                correoText.setText("Correo: " +user.getCorreo());
                palabrasText.setText("Palabras Jugadas: " + user.getPalabrasJugadas());
                puntajeText.setText("Puntaje obetenido: " + user.getPuntajeAcumulado());
                partidasText.setText("Partidas Ganadas: " + user.getPartidasGanadas());
                boton.setCommands(estadisticasMostrar);
                boton.pressButton(estadisticasText);
            } else {
                estadisticasText.setText("Objetivo no encontrado, vuelva a intentar.");
            }
        } else {
            System.out.println("No hay ningún usuario registrado");
        }
    }

    @FXML
    private Label eliminarText;

    @FXML
    protected void eliminarJugador(){
        Device device = new Device();
        Commands eliminar = new EliminarJugadorCommand(device);
        Boton boton = new Boton();

        this.users = LectorJson.leerDatos(this.users, "ListaUsuarios");
        int indice = Integer.parseInt(indiceJtext.getText());
        if (users.getListaUsuarios() != null && !users.getListaUsuarios().isEmpty()) {
            while(true) {
                if (indice >= 1 && indice <= users.getListaUsuarios().size()) {
                    System.out.println("Objetivo encontrado.");
                    users.getListaUsuarios().remove(indice - 1);
                    EscritorJson.guardarDatos(this.users, "ListaUsuarios");
                    boton.setCommands(eliminar);
                    boton.pressButton(eliminarText);
                    break;
                }
                eliminarText.setText("Objetivo inválido, vuelva a intentar.");
            }
        } else {
            System.out.println("No hay ningún usuario registrado");
        }
    }

    @FXML
    private Label datosText;

    @FXML
    protected void modificarDatos(){

        Device device = new Device();
        Commands modificar = new ModificarDatosCommand(device);
        Boton boton = new Boton();

        String name = nombreJtext.getText();
        String email = correoJtext.getText();
        this.users = LectorJson.leerDatos(this.users, "ListaUsuarios");
        int indice = Integer.parseInt(indiceJtext.getText());
        if (users.getListaUsuarios() != null && !users.getListaUsuarios().isEmpty()) {
            if (indice >= 1 && indice <= users.getListaUsuarios().size()) {
                System.out.println("Objetivo encontrado.");
                Usuario aModificar = (Usuario)users.getListaUsuarios().get(indice - 1);
                aModificar.modificarDatos(name, email);
                users.getListaUsuarios().set(indice - 1, aModificar);
                EscritorJson.guardarDatos(this.users, "ListaUsuarios");
                boton.setCommands(modificar);
                boton.pressButton(datosText);
            } else {
                datosText.setText("Objetivo no encontrado, vuelva a intentar.");
            }
        } else {
            System.out.println("No hay ningún usuario registrado");
        }
    }

    @FXML
    private Label listaText;

    @FXML
    protected void listaPartidas(){
        Device device = new Device();
        Commands lista = new ListaPartidaCommand(device);
        Boton boton = new Boton();

        boton.setCommands(lista);
        boton.pressButton(listaText);
    }

}