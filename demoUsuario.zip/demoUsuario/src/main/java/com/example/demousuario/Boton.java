package com.example.demousuario;

import javafx.scene.control.Label;

public class Boton{

    private Commands commands;

    public void setCommands(Commands commands) {
        this.commands = commands;
    }

    public void pressButton(Label label) {
        commands.execute(label);
    }
}
