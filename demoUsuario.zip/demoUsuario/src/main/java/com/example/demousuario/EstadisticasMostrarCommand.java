package com.example.demousuario;

import javafx.scene.control.Label;

public class EstadisticasMostrarCommand implements Commands{

    private Device device;

    public EstadisticasMostrarCommand(Device device) {
        this.device = device;
    }

    @Override
    public void execute(Label label) {
        device.estadisticasMostrar(label);
    }
}
