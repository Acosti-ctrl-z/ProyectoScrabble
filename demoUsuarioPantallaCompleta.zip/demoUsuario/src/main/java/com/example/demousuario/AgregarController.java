package com.example.demousuario;

import Datos.ListaUsuarios;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;


public class AgregarController {

    @FXML
    private Button BotonAgregar;



    @FXML
    protected void onAgregarUsuarioClick() throws IOException {
        Stage stage = (Stage) BotonAgregar.getScene().getWindow();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("AgregarUsuario.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    @FXML
    private Button BotonEstadisticas;

    @FXML
    protected void onVerEstadisticasClick() throws IOException {
        Stage stage = (Stage) BotonEstadisticas.getScene().getWindow();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Estadisticas.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    @FXML
    private Button BotonModificar;

    @FXML
    protected void onModificarDatosClick() throws IOException {
        Stage stage = (Stage) BotonModificar.getScene().getWindow();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("ModificarDatos.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    @FXML
    private Button BotonEliminar;

    @FXML
    protected void onEliminarJugadorClick() throws IOException {
        Stage stage = (Stage) BotonEliminar.getScene().getWindow();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("EliminarJugador.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    @FXML
    private Button BotonLista;

    @FXML
    protected void onMostrarListaClick() throws IOException {
        Stage stage = (Stage) BotonLista.getScene().getWindow();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("ListaPartidas.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    @FXML
    private Button BotonRegresar;

    @FXML
    protected void onRegresarMenuClick() throws IOException {
        Stage stage = (Stage) BotonRegresar.getScene().getWindow();
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Menu.fxml")));
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    @FXML
    private TextField nombreJtext;

    @FXML
    private TextField correoJtext;

    //@FXML
    //private ListaUsuarios users;

    @FXML
    private Label agregarText;

    @FXML
    protected void registroJugador() throws IOException{

        Device device = new Device();
        Commands agregarJugador = new AgregarJugadorCommand(device);
        Boton boton = new Boton();

        //String nombre = nombreJtext.getText();
        //        String correo = correoJtext.getText();
        //        this.users.agregarUsuarioNuevo(nombre, correo);

        boton.setCommands(agregarJugador);
        boton.pressButton(agregarText);

    }

}