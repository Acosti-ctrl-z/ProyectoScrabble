package Datos;

import java.util.List;

/**
 * Lista de las partidas jugadas
 */
public class ListaPartidas {
    private List<String> partidasList;

    /**
     * constructor de la clase ListaPartidas
     */
    public ListaPartidas() {
    }
}
