module com.example.demousuario {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires java.desktop;
    requires json.simple;

    opens com.example.demousuario to javafx.fxml;
    exports com.example.demousuario;
    exports Datos;
    opens Datos to javafx.fxml;
}