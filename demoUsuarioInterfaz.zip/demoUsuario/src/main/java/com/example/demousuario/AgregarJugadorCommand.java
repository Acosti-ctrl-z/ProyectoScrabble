package com.example.demousuario;

import javafx.scene.control.Label;

public class AgregarJugadorCommand implements Commands {
    private Device device;

    public AgregarJugadorCommand(Device device) {
        this.device = device;
    }

    @Override
    public void execute(Label label) {
        device.agregarJugador(label);
    }
}
