package com.example.demousuario;

import javafx.scene.control.Label;

public interface Commands {
    void execute(Label label);
}
