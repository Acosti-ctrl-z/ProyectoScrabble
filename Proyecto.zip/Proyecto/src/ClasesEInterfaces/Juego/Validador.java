package ClasesEInterfaces.Juego;

import ClasesEInterfaces.Datos.ListaDePalabras;

import java.util.Iterator;
import java.util.List;
import java.util.Objects;

/**
 * clase que valida varias situaciones en la partida
 */
public class Validador {
    /**
     * constructor del validadro
     */
    public Validador() {

    }

    /**
     * valida si un objeto es palabra
     * @param palabra la palabra a verificar
     * @return el resultado de la llamada al metodo verificacion de esta misma clase
     */
    public static boolean esPalabra(String palabra){
        String rut = "C:\\Users\\Dell\\IdeaProjects\\ProyectoScrabble-main\\Proyecto\\Lista_Rae_Scrabble.txt";
        List<String> palabras = ListaDePalabras.leerArchivo(rut);
        return ListaDePalabras.verificacion(palabras, palabra);
    }

    /** El metodo estaVacio() se encarga de verificar si la posicon esta disponible
     * @param posicion Tablero de la partida
     * @param fila numero de la fila
     * @param columna numero de la columna
     * @return verificacion de que la posicion esta disponible
     */
    public static boolean estaVacio(Tablero posicion, int fila, int columna){
        return posicion.getTablero()[fila - 1][columna - 1].getLetra().equals(" ");
    }

    /**
     * Verifica si el String ingresado es una palabra
     * @param lista la lista de palabras de la RAE obtenida de ManejoArchivos
     * @param palabraVerificar El String que se va a verificar
     * @return true si encontro la palabra en la lista, false si no la encontro
     */
    public static boolean verificacion(List<String> lista, String palabraVerificar) {
        Iterator var2 = lista.iterator();

        while(var2.hasNext()) {
            String s = (String)var2.next();
            if (Objects.equals(s, palabraVerificar)) {
                return true;
            }
        }

        return false;
    }

}

