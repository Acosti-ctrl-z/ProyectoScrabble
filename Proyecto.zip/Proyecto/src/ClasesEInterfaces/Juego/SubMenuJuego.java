package ClasesEInterfaces.Juego;

import ClasesEInterfaces.Recibir;
import ClasesEInterfaces.Iniciable;
import ClasesEInterfaces.Datos.ListaUsuarios;
import ClasesEInterfaces.Datos.Usuario;

import java.util.Iterator;

/**
 * menu de la parte del programa que maneja iniciar/continuar partidas y los jugadores
 */
public class SubMenuJuego implements Iniciable {
    private static boolean salir = false;
    private ListaUsuarios users;
    private Jugador jugador1;
    private Jugador jugador2;

    /**
     * constructor de ListaUsuarios
     * @param users lista de usuarios registrados
     */
    public SubMenuJuego(ListaUsuarios users) {
        this.users = users;
    }

    /**El metodo seleccionaJugador() selecciona el jugador para ver si se encuentra
     * @return verifica que se encuentre el jugador de la lista
     */
    public Jugador seleccionarJugador() {
        boolean encontrado = false;
        Jugador retornar = null;

        while(!encontrado) {
            String nombre = Recibir.recibirString("Ingrese su nombre de usuario");
            Iterator var4 = this.users.getListaUsuarios().iterator();

            while(var4.hasNext()) {
                Usuario usuario = (Usuario)var4.next();
                if (usuario.getAlias().equals(nombre)) {
                    retornar = new Jugador(usuario);
                    encontrado = true;
                }
            }

            if (!encontrado) {
                System.out.println("El usuario no fue encontrado, intente de nuevo.");
            }
        }

        return retornar;
    }

    /**Menu de inicio de la partida entre ambos jugadores
     */
    public void iniciar() {
        salir = false;
        System.out.println("Ingrese el nombre del jugador 1.");
        this.jugador1 = this.seleccionarJugador();
        System.out.println("Ingrese el nombre del jugador 2.");
        this.jugador2 = this.seleccionarJugador();

        while(!salir) {
            System.out.println("Opciones: ");
            System.out.println("1. Jugar una nueva partida.");
            System.out.println("2. Continuar partida anterior.");
            System.out.println("3. Ver estadísticas de los jugadores.");
            System.out.println("4. Retroceder. ");
            switch(Recibir.recibirInt("Ingrese su elección.")) {
                case 1:
                    System.out.println("Nueva partida");
                    Partida partida = new Partida(this.jugador1, this.jugador2);
                    partida.iniciar();
                    break;
                case 2:
                    System.out.println("Continuar partida");
                    break;
                case 3:
                    System.out.println("Mostrar información de jugadores");
                    System.out.print("1. ");
                    this.jugador1.mostrarDatos();
                    System.out.print("2. ");
                    this.jugador2.mostrarDatos();
                    break;
                case 4:
                    System.out.println("Cerrando submenú.");
                    salir = true;
                    break;
                default:
                    System.out.println("Ingrese una de las opciones sugeridas.");
            }
        }

    }
}

