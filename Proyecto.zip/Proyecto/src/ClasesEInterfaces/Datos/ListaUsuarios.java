package ClasesEInterfaces.Datos;

import ClasesEInterfaces.Recibir;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Lista de los usuarios registrados y sus metodos
 */
public class ListaUsuarios {
    private List<Usuario> listaUsuarios = new ArrayList();

    /**
     * getter de la lista de usuarios
     * @return el valor del atributo listaUsuarios (la lista de los usuarios)
     */
    public List<Usuario> getListaUsuarios() {
        return this.listaUsuarios;
    }

    /**
     * setter del atributo listaUsuarios en la clase
     * @param listaUsuarios la lista que se reemplazara con la actual
     */
    public void setListaUsuarios(List<Usuario> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }

    /**
     * constructor vacio de la clase ListaUsuarios
     */
    public ListaUsuarios() {
    }

    /**El metodo leerLista() lee la listaUsuarios
     */
    public void leerLista() {
        if (this.listaUsuarios != null && !this.listaUsuarios.isEmpty()) {
            int posicion = 1;

            for(Iterator var2 = this.listaUsuarios.iterator(); var2.hasNext(); ++posicion) {
                Usuario usuario = (Usuario)var2.next();
                System.out.print(posicion + ". ");
                usuario.mostrarDatos();
            }
        } else {
            System.out.println("No hay ningún usuario registrado");
        }

    }

    /** El metodo modificarUsuario() modofica los usuarios dentro de la lista
     */
    public void modificarUsuario() {
        if (this.listaUsuarios != null && !this.listaUsuarios.isEmpty()) {
            this.leerLista();
            int objetivo = Recibir.recibirInt("Escriba el índice del ususario a modificar");
            if (objetivo >= 1 && objetivo <= this.listaUsuarios.size()) {
                System.out.println("Objetivo encontrado.");
                Usuario aModificar = (Usuario)this.listaUsuarios.get(objetivo - 1);
                aModificar.modificarDatos();
                this.listaUsuarios.set(objetivo - 1, aModificar);
                System.out.println("Usuario modificado.");
            } else {
                System.out.println("Objetivo no encontrado, vuelva a intentar.");
            }
        } else {
            System.out.println("No hay ningún usuario registrado");
        }

    }

    /** El metodo eliminarUsuario() elimina un usuario dentro de la lista
     */
    public void eliminarUsuario() {
        if (this.listaUsuarios != null && !this.listaUsuarios.isEmpty()) {
            this.leerLista();

            while(true) {
                int objetivo = Recibir.recibirInt("Escriba el índice del ususario a borar");
                if (objetivo >= 1 && objetivo <= this.listaUsuarios.size()) {
                    System.out.println("Objetivo encontrado.");
                    this.listaUsuarios.remove(objetivo - 1);
                    System.out.println("Usuario eliminado.");
                    break;
                }

                System.out.println("Objetivo inválido, vuelva a intentar.");
            }
        } else {
            System.out.println("No hay ningún usuario registrado");
        }

    }

    /**
     * metodo para agregar un usuario nuevo a la lista
     */
    public void agregarUsuarioNuevo() {
        this.listaUsuarios.add(new Usuario());
    }

    /**
     * metodo para agregar un usuario ya creado a la lista
     * @param usuario el usuario a agregr
     */
    public void agregarUsuario(Usuario usuario) {
        this.listaUsuarios.add(usuario);
    }
}