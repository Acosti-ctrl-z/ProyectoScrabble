package ClasesEInterfaces.Datos;

import ClasesEInterfaces.Juego.Partida;

import java.util.List;

/**
 * Lista de las partidas jugadas
 */
public class ListaPartidas {
    private List<Partida> partidasList;

    /**
     * constructor de la clase ListaPartidas
     */
    public ListaPartidas() {
    }
}
