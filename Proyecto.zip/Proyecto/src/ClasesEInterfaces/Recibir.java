package ClasesEInterfaces;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Clase que se encarga de manejar casos cuando el usuario escribe por el teclado
 */
public class Recibir {
    private static boolean valid = false;
    private static Scanner lectura;
    private static String revisar;

    /**
     * Constructor de Recibir
     */
    public Recibir() {
    }

    /** El recibirInt()verifica el valor de entero
     * @param mensaje Valor
     * @return verificacion de que el valor ingresado es un entero
     */
    public static int recibirInt(String mensaje) {
        while(!valid) {
            System.out.print(mensaje + " ");
            revisar = lectura.next();
            if (revisar.matches("[0-9]*")) {
                return Integer.parseInt(revisar);
            }

            System.out.println("Ingreso un dato invalido, intente de nuevo.");
        }

        return 0;
    }

    /** El metodo recibirString() verifica si el valor es un String
     * @param mensaje String
     * @return verifica que sea un string
     */
    public static String recibirString(String mensaje) {
        System.out.print(mensaje + " ");
        return lectura.next();
    }

    /** El metodo recibirEmail() verifica que sea un Strin formato email
     * @param mensaje Correo
     * @return verificacion del formato email
     */
    public static String recibirEmail(String mensaje) {
        boolean aprobado = false;
        String email = "";

        while(!aprobado) {
            Pattern pattern = Pattern.compile("^([0-9a-zA-Z]+[-._+&])*[0-9a-zA-Z]+@([-0-9a-zA-Z]+[.])+[a-zA-Z]{2,6}$");
            email = recibirString(mensaje);
            Matcher matcher = pattern.matcher(email);
            aprobado = matcher.matches();
            if (!aprobado) {
                System.out.println("Lo ingresado no estuvo en formato email.");
            }
        }

        return email;
    }

    /** el metodo recibirDimension() recibir un numero entre 1 y 15
     * @param mensaje Valor
     * @return retorna el valor verificado
     */
    public static int recibirDimension(String mensaje) {
        boolean aprobado = false;
        int dimension = 0;

        while(!aprobado) {
            dimension = recibirInt(mensaje);
            if(dimension>0&&dimension<16){
                aprobado=true;
            }else{
                System.out.println("Lo ingresado debe estar entre 1 y 15.");
            }
        }

        return dimension;
    }
    static {
        lectura = new Scanner(System.in);
        revisar = "";
    }
}
