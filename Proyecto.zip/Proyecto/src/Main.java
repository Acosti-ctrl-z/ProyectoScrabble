import ClasesOrganizarLuego.Menu;

/**Clase Main que ejecuta el scrabble
 * para poder jugar al codigo
 * @author Jesus Acosta
 * @author Rolando Rodrigo
 * @author Leonel Rojas
 */
public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.iniciar();
    }
}