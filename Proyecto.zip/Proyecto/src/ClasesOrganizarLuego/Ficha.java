package ClasesOrganizarLuego;

public class Ficha {
    private String letra;
    private int puntaje;

    /** Se crean las fichas para el juego
     * @param letra Letra del abecedario
     * @param puntaje puntaje de la ficha
     */
    public Ficha(String letra, int puntaje) {
        this.letra = letra;
        this.puntaje = puntaje;
    }

    public String getLetra() {
        return this.letra;
    }

    public int getPuntaje() {
        return this.puntaje;
    }

    public void setLetra(String letra) {
        this.letra = letra;
    }

    public void setPuntaje(int puntaje) {
        this.puntaje = puntaje;
    }
}
