package ClasesOrganizarLuego;

public interface Iniciable {
    /**Interfaz Iniciable, que ayuda a usar el metodo iniciar() en el codigo
     *
     */
    void iniciar();

}
