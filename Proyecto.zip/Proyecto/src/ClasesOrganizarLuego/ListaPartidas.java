package ClasesOrganizarLuego;

import java.util.List;

public class ListaPartidas {
    private List<Partida> partidasList;

    public ListaPartidas() {
    }
}
